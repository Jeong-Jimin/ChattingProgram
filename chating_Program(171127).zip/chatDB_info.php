<?php
class chatDB_info{
    const DB_url = "localhost";
    const DB_host = "root";
    const DB_PW = "autoset";
    const DB_name = "chat";
}
?>